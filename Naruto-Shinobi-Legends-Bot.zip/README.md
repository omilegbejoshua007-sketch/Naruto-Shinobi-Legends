# Naruto Shinobi Legends — WhatsApp Group RPG

## Run
1. Install Node.js 20+.
2. Run `npm install`
3. Run `npm start`
4. The bot prints a WhatsApp pairing code in the terminal when BOT_PHONE is set.
5. On the phone that owns the WhatsApp account: WhatsApp > Linked devices > Link a device > Link with phone number instead.
6. Enter the pairing code.
7. Add the bot account to your WhatsApp group.

The bot ignores private chats and only responds in WhatsApp groups.

## Commands
/register <name>
/profile
/villages
/join <leaf|sand|mist|cloud|stone|rain>
/jutsu
/train
/mission
/daily
/battle @user
/attack
/use <jutsu>
/defend
/flee
/leaderboard
/help

This is an unofficial WhatsApp Web integration. Use a normal account and avoid spam/bulk messaging.
