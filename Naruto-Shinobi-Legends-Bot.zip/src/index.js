import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore
} from "@whiskeysockets/baileys";
import P from "pino";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import qrcode from "qrcode-terminal";
import readline from "readline";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA = path.join(__dirname, "../data/players.json");
const AUTH = path.join(__dirname, "../auth");
const log = P({ level: "silent" });

function load() {
  try { return JSON.parse(fs.readFileSync(DATA, "utf8")); }
  catch { return {}; }
}
function save(db) {
  fs.writeFileSync(DATA, JSON.stringify(db, null, 2));
}
const db = load();
const battles = new Map();

const villages = {
  leaf: "🍃 Hidden Leaf",
  sand: "🏜️ Hidden Sand",
  mist: "🌫️ Hidden Mist",
  cloud: "⚡ Hidden Cloud",
  stone: "🪨 Hidden Stone",
  rain: "🌧️ Hidden Rain"
};

const jutsu = {
  "rasengan": {name:"Rasengan", cost:20, power:34},
  "chidori": {name:"Chidori", cost:24, power:40},
  "fireball": {name:"Fireball Jutsu", cost:18, power:30},
  "shadow-clone": {name:"Shadow Clone", cost:12, power:22}
};

function idOf(m) {
  return m.key.participant || m.key.remoteJid;
}
function mentionId(m) {
  return idOf(m);
}
function ensure(uid, name="Shinobi") {
  if (!db[uid]) db[uid] = {
    name, village:null, level:1, xp:0, hp:100, chakra:100,
    attack:12, defense:10, speed:10, ryo:500, wins:0, losses:0
  };
  return db[uid];
}
function xpNeed(p){ return 100 + (p.level-1)*75; }
function addXp(p,n){
  p.xp += n;
  let leveled = false;
  while(p.xp >= xpNeed(p)){
    p.xp -= xpNeed(p);
    p.level++;
    p.hp += 15; p.chakra += 15; p.attack += 3; p.defense += 2; p.speed += 2;
    leveled = true;
  }
  return leveled;
}
function getText(m){
  return m.message?.conversation ||
    m.message?.extendedTextMessage?.text ||
    m.message?.imageMessage?.caption || "";
}
function groupOnly(jid){ return jid?.endsWith("@g.us"); }
function tag(uid){ return `@${uid.split("@")[0]}`; }

async function start(){
  const { state, saveCreds } = await useMultiFileAuthState(AUTH);
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({
    version,
    logger: log,
    printQRInTerminal: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, log)
    },
    browser: ["Shinobi Legends", "Chrome", "1.0"]
  });

  sock.ev.on("creds.update", saveCreds);

  if (!state.creds.registered) {
    const phone = (process.env.BOT_PHONE || "").replace(/\D/g,"");
    if (phone) {
      setTimeout(async () => {
        try {
          const code = await sock.requestPairingCode(phone);
          console.log("\nPAIRING CODE:", code, "\n");
          console.log("WhatsApp > Linked devices > Link a device > Link with phone number instead.\n");
        } catch(e) {
          console.log("Pairing code error:", e.message);
          console.log("QR fallback may be available depending on your host.");
        }
      }, 3000);
    } else {
      console.log("Set BOT_PHONE to your WhatsApp number in international format to receive a pairing code.");
    }
  }

  sock.ev.on("connection.update", async ({connection, lastDisconnect, qr}) => {
    if (qr) {
      console.log("\nScan this QR with WhatsApp:\n");
      qrcode.generate(qr, {small:true});
    }
    if (connection === "open") console.log("🍃 Shinobi Legends is ONLINE.");
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut) {
        console.log("Connection closed. Reconnecting...");
        start();
      } else {
        console.log("Logged out. Delete auth folder and pair again.");
      }
    }
  });

  sock.ev.on("messages.upsert", async ({messages}) => {
    const m = messages[0];
    if (!m?.message) return;
    const jid = m.key.remoteJid;
    if (!groupOnly(jid) || m.key.fromMe) return;

    const text = getText(m).trim();
    if (!text.startsWith("/")) return;
    const [raw, ...args] = text.split(/\s+/);
    const cmd = raw.toLowerCase();

    const uid = mentionId(m);
    const p = ensure(uid, m.pushName || "Shinobi");
    const send = (s, mentions=[]) => sock.sendMessage(jid, {text:s, mentions});

    if (cmd === "/help") return send(
`🍃 NARUTO SHINOBI LEGENDS

/register <name>
/profile
/villages
/join <village>
/jutsu
/train
/mission
/daily
/battle @user
/attack
/use <jutsu>
/defend
/flee
/leaderboard

⚔️ Group RPG only.`
    );

    if (cmd === "/register") {
      const name = args.join(" ").trim();
      if (!name) return send("Usage: /register Naruto");
      if (db[uid]?.registered) return send("You are already registered. Use /profile.");
      p.name = name; p.registered = true; save(db);
      return send(`🍃 Welcome, ${name}! Your shinobi journey begins. Use /join leaf to choose a village.`);
    }

    if (!p.registered) return send("❌ Register first with /register <name>");

    if (cmd === "/profile") return send(
`🥷 ${p.name}
🏯 Village: ${p.village ? villages[p.village] : "None"}
⭐ Level: ${p.level} | XP: ${p.xp}/${xpNeed(p)}
❤️ HP: ${p.hp}
🔵 Chakra: ${p.chakra}
⚔️ ATK: ${p.attack} | 🛡️ DEF: ${p.defense} | 💨 SPD: ${p.speed}
💰 Ryo: ${p.ryo}
🏆 W/L: ${p.wins}/${p.losses}`
    );

    if (cmd === "/villages") return send(
`🍃 leaf — Hidden Leaf
🏜️ sand — Hidden Sand
🌫️ mist — Hidden Mist
⚡ cloud — Hidden Cloud
🪨 stone — Hidden Stone
🌧️ rain — Hidden Rain

Join: /join leaf`
    );

    if (cmd === "/join") {
      const v = args[0]?.toLowerCase();
      if (!villages[v]) return send("❌ Unknown village. Use /villages.");
      p.village = v; save(db);
      return send(`🏯 ${p.name} is now a shinobi of ${villages[v]}!`);
    }

    if (cmd === "/jutsu") return send(
`🔥 Your jutsu:
• /use rasengan — 20 chakra, 34 power
• /use chidori — 24 chakra, 40 power
• /use fireball — 18 chakra, 30 power
• /use shadow-clone — 12 chakra, 22 power`
    );

    if (cmd === "/train") {
      const gain = 15 + Math.floor(Math.random()*16);
      const level = addXp(p, gain);
      p.chakra = Math.min(100, p.chakra + 10);
      p.hp = Math.min(100 + (p.level-1)*15, p.hp + 10);
      p.ryo += 50;
      save(db);
      return send(`🥋 Training complete!\n+${gain} XP\n+50 Ryo\n${level ? "🎉 LEVEL UP! You are now level "+p.level+"." : ""}`);
    }

    if (cmd === "/mission") {
      const rewards = [
        ["D-Rank",80,20],["C-Rank",140,35],["B-Rank",220,55],["A-Rank",350,80],["S-Rank",600,120]
      ];
      const [rank,ryo,xp] = rewards[Math.floor(Math.random()*rewards.length)];
      p.ryo += ryo; const level = addXp(p,xp); save(db);
      return send(`📜 ${rank} Mission completed!\n💰 +${ryo} Ryo\n⭐ +${xp} XP${level ? "\n🎉 LEVEL UP!":""}`);
    }

    if (cmd === "/daily") {
      const today = new Date().toISOString().slice(0,10);
      if (p.daily === today) return send("⏳ You already claimed today's reward.");
      p.daily=today; p.ryo+=300; p.chakra=100; save(db);
      return send("🎁 Daily reward claimed!\n💰 +300 Ryo\n🔵 Chakra restored.");
    }

    if (cmd === "/leaderboard") {
      const list = Object.values(db).filter(x=>x.registered).sort((a,b)=>(b.level*1000+b.xp)-(a.level*1000+a.xp)).slice(0,10);
      return send("🏆 SHINOBI LEADERBOARD\n"+list.map((x,i)=>`${i+1}. ${x.name} — Lv.${x.level} (${x.xp} XP)`).join("\n"));
    }

    if (cmd === "/battle") {
      const target = [...(m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [])][0];
      if (!target || target === uid) return send("⚔️ Mention one player: /battle @user");
      const t = ensure(target);
      if (!t.registered) return send("❌ That player is not registered.");
      if (battles.has(jid)) return send("⚔️ A battle is already active in this group.");
      battles.set(jid,{attacker:uid, defender:target, turn:uid, defending:null});
      return send(`⚔️ BATTLE START!\n${tag(uid)} challenges ${tag(target)}!\n\n${tag(uid)} goes first.\nUse /attack, /use <jutsu>, /defend or /flee.`,[uid,target]);
    }

    const b = battles.get(jid);
    if (!b) return;
    if (![b.attacker,b.defender].includes(uid)) return;
    if (b.turn !== uid) return send(`⏳ It's ${tag(b.turn)}'s turn.`,[b.turn]);

    const me = ensure(uid);
    const enemyId = uid===b.attacker ? b.defender : b.attacker;
    const enemy = ensure(enemyId);

    if (cmd === "/defend") {
      b.defending=uid;
      b.turn=enemyId;
      return send(`🛡️ ${tag(uid)} is defending.\n${tag(enemyId)}'s turn.`,[uid,enemyId]);
    }

    if (cmd === "/flee") {
      me.losses++; enemy.wins++; save(db); battles.delete(jid);
      return send(`🏃 ${tag(uid)} fled the battle! ${tag(enemyId)} wins.`,[uid,enemyId]);
    }

    let power = 0, action = "";
    if (cmd === "/attack") {
      power = Math.max(1, me.attack + Math.floor(Math.random()*8) - enemy.defense);
      action = "👊 Basic attack";
    } else if (cmd === "/use") {
      const key=args[0]?.toLowerCase();
      const j=jutsu[key];
      if (!j) return send("❌ Unknown jutsu. Use /jutsu.");
      if (me.chakra < j.cost) return send("🔵 Not enough chakra.");
      me.chakra -= j.cost;
      power = Math.max(1, j.power + me.attack/2 + Math.floor(Math.random()*8) - enemy.defense/2);
      action = `🔥 ${j.name}`;
    } else return send("Use /attack, /use <jutsu>, /defend or /flee.");

    if (b.defending === enemyId) power = Math.max(1, Math.floor(power*0.5));
    b.defending=null;
    enemy.hp -= Math.floor(power);

    if (enemy.hp <= 0) {
      me.wins++; enemy.losses++;
      const reward = 150 + enemy.level*25;
      me.ryo += reward;
      addXp(me, 60 + enemy.level*10);
      enemy.hp = Math.max(1, 100 + (enemy.level-1)*15);
      enemy.chakra = 100;
      save(db); battles.delete(jid);
      return send(`💥 ${action}!\n${tag(uid)} dealt ${Math.floor(power)} damage.\n\n🏆 ${tag(uid)} WINS!\n💰 +${reward} Ryo\n⭐ Battle XP earned.`,[uid,enemyId]);
    }

    b.turn=enemyId;
    save(db);
    return send(`${action}!\n💥 ${tag(uid)} dealt ${Math.floor(power)} damage.\n❤️ ${tag(enemyId)} HP: ${enemy.hp}\n\n➡️ ${tag(enemyId)}'s turn.`,[uid,enemyId]);
  });
}

start().catch(e => console.error(e));
